const smallFontButton = document.getElementById("small-font");
const mediumFontButton = document.getElementById("medium-font");
const largeFontButton = document.getElementById("large-font");
const bodyElement = document.querySelector('body');

function setFontSize(size) {
    bodyElement.style.fontSize = size;
}

small-font.addEventListener("click", function() {
    setFontSize("12px");
});

medium-font.addEventListener("click", function() {
    setFontSize("20px");
});

large-font.addEventListener("click", function() {
    setFontSize("30px");
});